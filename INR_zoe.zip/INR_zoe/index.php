<!DOCTYPE html>
<html lang="fr">
  <head>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="style/style.css">
    <title>archives</title>
  </head>

  <body>
    
    <?php 
      require "articles.php"; 
    ?>
  
  </body>

</html>
